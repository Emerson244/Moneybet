function login() {
  const user = document.getElementById("username").value;
  const pass = document.getElementById("password").value;

  if (user === "admin" && pass === "123456") {
    window.location.href = "admin.html";
  } else if (user === "user" && pass === "123456") {
    window.location.href = "home.html";
  } else {
    alert("Login inválido!");
  }
}